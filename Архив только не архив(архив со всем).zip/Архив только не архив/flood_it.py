import pygame
import random


class Board:
    # создание поля
    def __init__(self, width, height):
        self.krai = 30
        self.x = 45
        self.y = 15
        self.width = width
        self.height = height
        self.board = [[random.randint(0, 5) for v in range(height)] for _ in range(height)]
        self.color = [(255, 255, 255)]
        # значения по умолчанию
        self.left = 10
        self.top = 10
        self.cell_size = 30

        self.schetchic = 0
    # настройка внешнего вида
    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self):
        b1 = len(self.board)
        b2 = len(self.board[0])
        for i in range(b1):
            for v in range(b2):
                color = self.color = [(255, 0, 0), (0, 255, 0), (0, 0, 255),
                                      (255, 255, 0), (255, 0, 255), (0, 255, 255)]
                pygame.draw.rect(screen, color[self.board[i][v]],
                                 ((self.x + v * self.krai - 1, self.y + i * self.krai - 1), (self.krai + 1, self.krai + 1)))

                font = pygame.font.Font(None, 40)
                text = font.render(f'Ход номер: {self.schetchic}', True, (255, 255, 255), (0, 0, 0))
                screen.blit(text, (0, 0))

                font = pygame.font.Font(None, 20)
                text = font.render(f'Для рестарта пробел', True, (255, 255, 255), (0, 0, 0))
                screen.blit(text, (250, 15))

    def set_view(self, x, y, t):
        self.x = x
        self.y = y
        self.krai = t

    def get_click(self, mouse_pos):
        cell = self.get_cell(mouse_pos)
        self.on_click(cell)

    def get_cell(self, x_y):
        x, y = x_y
        x -= self.x
        y -= self.y
        if x < 0 or y < 0 or self.width * self.krai < x or self.height * self.krai < y:
            return None
        a = x // self.krai
        b = y // self.krai
        return (a, b)

    def on_click(self, cell):
        if cell != None:
            y, x = cell
            if self.board[x][y] != self.board[0][0]:
                self.schetchic += 1
                self.rekurs(self.board[x][y], self.board[0][0], 0, 0)

    def rekurs(self, par, idl, x, y):
        if self.board[x][y] == idl:
            self.board[x][y] = par
            if x - 1 >= 0:
                self.rekurs(par, idl, x - 1, y)
            if x + 1 <= 14:
                self.rekurs(par, idl, x + 1, y)
            if y - 1 >= 0:
                self.rekurs(par, idl, x, y - 1)
            if y + 1 <= 14:
                self.rekurs(par, idl, x, y + 1)

    def restart(self):
        self.board = [[random.randint(0, 5) for v in range(15)] for _ in range(15)]
        self.schetchic = 0

if __name__ == '__main__':
    pygame.init()
    size = width, height = 470, 490
    screen = pygame.display.set_mode(size)
    board = Board(15, 15)
    board.set_view(10, 30, 30)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                board.get_click(event.pos)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    board.restart()
        screen.fill((0, 0, 0))
        board.render()
        pygame.display.flip()
    pygame.quit()
