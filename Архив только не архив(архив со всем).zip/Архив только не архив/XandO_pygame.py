import pygame


class Board:
    # создание поля
    def __init__(self, width, height):
        self.POPO = 1
        self.krai = 30
        self.x = 10
        self.y = 30
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        # значения по умолчанию
        self.left = 10
        self.top = 10
        self.cell_size = 30
        self.KLIKLI = True

        self.win = False

    # настройка внешнего вида
    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self, screen):
        b1 = len(self.board)
        b2 = len(self.board[0])
        for i in range(b1):
            for v in range(b2):
                color = [(255, 255, 255), (255, 0, 0), (0, 0, 255)]
                if self.board[i][v] == 1:
                    pygame.draw.line(screen, color[2], (self.x + v * self.krai, self.y + i * self.krai),
                                     (self.x + (v + 1) * self.krai, self.y + (i + 1) * self.krai), 3)
                    pygame.draw.line(screen, color[2], (self.x + (v + 1) * self.krai, self.y + i * self.krai),
                                     (self.x + v * self.krai, self.y + (i + 1) * self.krai), 3)
                elif self.board[i][v] == 2:
                    pygame.draw.circle(screen, color[1], (self.x + v * self.krai + 50, 50 + self.y + i * self.krai), 50,
                                       3)
                pygame.draw.rect(screen, color[0],
                                 ((self.x + v * self.krai, self.y + i * self.krai), (self.krai + 1, self.krai + 1)), 2)
        if self.win:
            font = pygame.font.Font(None, 45)
            text = font.render(f'Победил: {self.win}', True, (255, 255, 255), (0, 0, 0))
            screen.blit(text, (0, 0))

            font = pygame.font.Font(None, 20)
            text = font.render(f'Для рестарта пробел', True, (255, 255, 255), (0, 0, 0))
            screen.blit(text, (0, 335))

    def set_view(self, x, y, t):
        self.x = x
        self.y = y
        self.krai = t

    def get_click(self, mouse_pos):
        cell = self.get_cell(mouse_pos)
        if cell:
            self.on_click(cell)

    def get_cell(self, x_y):
        x, y = x_y
        x -= self.x
        y -= self.y
        if x < 0 or y < 0 or self.width * self.krai < x or self.height * self.krai < y:
            return False
        a = x // self.krai
        b = y // self.krai
        return (a, b)

    def on_click(self, cell):
        if self.KLIKLI:
            if cell != None:
                y, x = cell
                b1 = len(self.board)
                b2 = len(self.board[0])
                if self.board[x][y] == 0:
                    self.board[x][y] = self.POPO
                    if self.POPO == 1:
                        self.POPO = 2
                    else:
                        self.POPO = 1
            self.check(x, y)

    def check(self, x, y):
        A = ''
        B = ''
        i = self.board
        for v in i:
            B += str(v[y])
        A += ' ' + B
        B = ''
        for v in range(3):
            B += str(i[x][v])
        A += ' ' + B
        B1 = ''
        B2 = ''
        x1, y1, z = 0, y - x, 0
        while y1 < 3 or x1 < 3:
            if 0 <= y1 < 3 and 0 <= x1 < 3:
                B1 += str(i[x1][y1])
            if 0 <= y + x - z < 3 and 0 <= x1 < 3:
                B2 += str(i[x1][y + x - z])
            x1 += 1
            y1 += 1
            z += 1
        A += ' ' + B1 + ' ' + B2
        C = []
        for i in self.board:
            C.append(i[0])
            C.append(i[1])
            C.append(i[2])
        if '111' in A:
            self.Pobeda('Синий')
        elif '222' in A:
            self.Pobeda('Красный')
        elif 0 not in C:
            self.Pobeda('Ничья')

    def Pobeda(self, a):
        self.win = a
        self.KLIKLI = False

    def restart(self):
        self.KLIKLI = True
        self.win = False
        self.board = [[0] * self.width for _ in range(self.height)]




def main():
    pygame.init()
    size = width, height = 320, 350
    screen = pygame.display.set_mode(size)
    board = Board(3, 3)
    board.set_view(10, 30, 100)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                board.get_click(event.pos)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    board.restart()
        screen.fill((0, 0, 0))
        board.render(screen)
        pygame.display.flip()
    pygame.quit()
main()