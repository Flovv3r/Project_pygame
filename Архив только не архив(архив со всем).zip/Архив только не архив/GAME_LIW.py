import pygame

class Board:
    # создание поля
    def __init__(self, width, height):
        self.pointes = 0
        self.krai = 30
        self.x = 15
        self.y = 15
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        # значения по умолчанию
        self.left = 10
        self.top = 10
        self.cell_size = 30

    # настройка внешнего вида
    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self, screen):
        b1 = len(self.board)
        b2 = len(self.board[0])
        if self.pointes == 1:
            #print(self.board)
            #print(1)
            self.board = self.prawila()
            #print(self.board)
            ##self.pointes -= 1
        for i in range(b1):
            for v in range(b2):
                color = [(255, 255, 255), (0, 255, 0)]
                pygame.draw.rect(screen, color[0], ((self.x + v * self.krai, self.y + i * self.krai), (self.krai + 1, self.krai + 1)), 1)
                if self.board[i][v] == 1:
                    pygame.draw.rect(screen, color[1], ((self.x + v * self.krai, self.y + i * self.krai), (self.krai + 1, self.krai + 1)))
    def set_view(self, x, y, t):
        self.x = x
        self.y = y
        self.krai = t
        
    def get_click(self, mouse_pos):
        cell = self.get_cell(mouse_pos)
        self.on_click(cell)

    def get_cell(self, x_y):
        x, y = x_y
        x -= self.x
        y -= self.x
        if x< 0 or y < 0 or self.width * self.krai < x or self.height * self.krai < y:
            return None
        a = x // self.krai
        b = y // self.krai
        return (a, b)

    def on_click(self, cell):
        if cell != None:
            y, x = cell
            self.board[x][y] = (self.board[x][y] + 1) % 2

    def next_move(self):
        self.pointes = (self.pointes + 1) % 2

    def prawila(self):
        Poli = [[0] * self.width for _ in range(self.height)]
        I = self.board
        H = [-1, 0, 1]
        b1 = len(self.board)
        b2 = len(self.board[0])
        for i in range(b1):
            for v in range(b2):
                s = 0
                for g in range(9):
                    if g != 4:
                        s += I[(i + H[g // 3]) % b1][(v + H[g % 3]) % b1]
                if s == 3:
                    Poli[i][v] = 1
                elif s == 2:
                    if I[i][v] == 1:
                        Poli[i][v] = 1
        return Poli
                
        
        
  

def GOGO():
    pygame.init()
    size = width, height = 500, 500
    screen = pygame.display.set_mode(size)
    board = Board(480 // 15, 480 // 15)
    
    clock = pygame.time.Clock()
    
    board.set_view(10, 10, 15)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    board.get_click(event.pos)
                elif event.button == 3:
                    board.next_move()
        screen.fill((0, 0, 0))
        board.render(screen)
        clock.tick(10)
        pygame.display.flip()
    pygame.quit()
GOGO()