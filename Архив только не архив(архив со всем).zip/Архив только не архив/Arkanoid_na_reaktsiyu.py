import os
import sys
import random

import pygame


class Tile(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__(all_sprites)
        self.image = pygame.Surface((40, 10), pygame.SRCALPHA)
        pygame.draw.rect(self.image, pygame.Color("yellow"),
                           (0, 0, 30, 30))
        self.rect = pygame.Rect(50 + 40 * x, 50 + 40 * y, 30, 30)
        self.add(tile)
        

class Stick(pygame.sprite.Sprite):
    def __init__(self, x_pos):
        global width, height
        super().__init__(all_sprites)
        self.x_pos = x_pos
        self.image = pygame.Surface((40, 10), pygame.SRCALPHA)
        pygame.draw.rect(self.image, pygame.Color('blue'),
                         (0, 0, 40, 10))
        self.rect = pygame.Rect(self.x_pos - 20, height - 20, self.x_pos + 20, height - 10)
        self.add(stick1)
        
    def move(self, x_pos):
        self.rect = self.rect.move(-self.x_pos + x_pos, 0)
        self.x_pos = x_pos
          
# Изображение не получится загрузить 
# без предварительной инициализации pygame
def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


class Ball(pygame.sprite.Sprite):
    def __init__(self, radius, x, y):
        super().__init__(all_sprites)
        self.radius = radius
        self.image = pygame.Surface((2 * radius, 2 * radius),
                                    pygame.SRCALPHA, 32)
        pygame.draw.circle(self.image, pygame.Color("red"),
                           (radius, radius), radius)
        self.rect = pygame.Rect(x, y, 2 * radius, 2 * radius)
        self.vx = random.randint(1, 3)
        self.vy = random.randint(-3, -1)
        self.add(balls)

    # движение с проверкой столкновение шара со стенками
    def update(self):
        global running
        self.rect = self.rect.move(self.vx, self.vy)
        if pygame.sprite.spritecollideany(self, horizontal_border1):
            self.vy = -self.vy
        if pygame.sprite.spritecollideany(self, vertical_borders):
            self.vx = -self.vx
        if pygame.sprite.spritecollideany(self, horizontal_border2):
            running = False
        if pygame.sprite.spritecollideany(self, stick1):
            self.vy = -self.vy
            self.vx = random.randint(-4, 4)
            while self.vx == 0:
                self.vx = random.randint(-4, 4)
        if pygame.sprite.spritecollide(self, tile, True):
            self.vy = random.randint(-4, 4)
            while self.vy == 0:
                self.vy = random.randint(-4, 4)
            self.vx = random.randint(-4, 4)
            while self.vx == 0:
                self.vx = random.randint(-4, 4)
        collided = any(self.rect.colliderect(block.rect)
                       for block in balls if self != block)
        if collided:
            self.vy = -self.vy
            self.vx = -self.vx


class Border(pygame.sprite.Sprite):
    # строго вертикальный или строго горизонтальный отрезок
    def __init__(self, x1, y1, x2, y2):
        super().__init__(all_sprites)
        if x1 == x2:  # вертикальная стенка
            self.add(vertical_borders)
            self.image = pygame.Surface([1, y2 - y1])
            self.rect = pygame.Rect(x1, y1, 1, y2 - y1)
            # горизонтальная стенка
        elif x2 == y2:
            self.add(horizontal_border2)
            self.image = pygame.Surface([x2 - x1, 1])
            self.rect = pygame.Rect(x1, y1, x2 - x1, 1)
        else:  # горизонтальная стенка
            self.add(horizontal_border1)
            self.image = pygame.Surface([x2 - x1, 1])
            self.rect = pygame.Rect(x1, y1, x2 - x1, 1)


def load_level(filename):
    filename = "data/" + filename
    # читаем уровень, убирая символы перевода строки
    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]

    # и подсчитываем максимальную длину    
    max_width = max(map(len, level_map))

    # дополняем каждую строку пустыми клетками ('.')    
    return list(map(lambda x: x.ljust(max_width, '.'), level_map))


def generate_level(level):
    x, y = None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '1':
                Tile(x, y)
        

if __name__ == '__main__':
    fps = 100
    nlevel = 1
    level = load_level(str(nlevel) + '.txt')
    pygame.init()
    screen = pygame.display.set_mode((300, 400))
    width = pygame.display.get_surface().get_size()[0]
    height = pygame.display.get_surface().get_size()[0]
    horizontal_border1 = pygame.sprite.Group()
    horizontal_border2 = pygame.sprite.Group()
    vertical_borders = pygame.sprite.Group()
    pygame.display.set_caption('Арканоид_на_реакцию')
    running = True
    balls = pygame.sprite.Group()
    stick1 = pygame.sprite.Group()
    tile = pygame.sprite.Group()
    all_sprites = pygame.sprite.Group()
    stick = Stick(width // 2)
    Border(5, 5, width - 5, 5)
    Border(5, height - 5, width - 5, height - 5)
    Border(5, 5, 5, height - 5)
    Border(width - 5, 5, width - 5, height - 5)
    screen.fill((255, 255, 255))
    for i in range(1):
        Ball(5, 150, 200)
    x, y = 0, 0
    clock = pygame.time.Clock()
    generate_level(level)
    no = True
    while no:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                no = False
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEMOTION:
                stick.move(event.pos[0])
        all_sprites.update()
        screen.fill((255, 255, 255))
        all_sprites.draw(screen)
        clock.tick(fps)
        pygame.display.flip()
        if len(tile.sprites()) == 0:
            nlevel += 1
            level = load_level(str(nlevel) + '.txt')
            pygame.init()
            screen = pygame.display.set_mode((300, 400))
            width = pygame.display.get_surface().get_size()[0]
            height = pygame.display.get_surface().get_size()[0]
            horizontal_border1 = pygame.sprite.Group()
            horizontal_border2 = pygame.sprite.Group()
            vertical_borders = pygame.sprite.Group()
            pygame.display.set_caption('Арканоид_на_реакцию')
            running = True
            balls = pygame.sprite.Group()
            stick1 = pygame.sprite.Group()
            tile = pygame.sprite.Group()
            all_sprites = pygame.sprite.Group()
            stick = Stick(width // 2)
            Border(5, 5, width - 5, 5)
            Border(5, height - 5, width - 5, height - 5)
            Border(5, 5, 5, height - 5)
            Border(width - 5, 5, width - 5, height - 5)
            screen.fill((255, 255, 255))
            for i in range(1):
                Ball(5, 150, 200)
            x, y = 0, 0
            clock = pygame.time.Clock()
            generate_level(level)
            no = True
            while no:
                for event in pygame.event.get():
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        no = False
                    if nlevel == 5:
                        running = False
    screen.fill((0, 0, 0))
    font = pygame.font.Font(None, 50)
    if nlevel == 5:
        text = font.render("You win!!!", True, (100, 255, 100))
    else:
        text = font.render("You lose!!!", True, (100, 255, 100))
    text_x = width // 2 - text.get_width() // 2
    text_y = height // 2 - text.get_height() // 2
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (0, 255, 0), (text_x - 10, text_y - 10,
                                           text_w + 20, text_h + 20), 1)
    pygame.display.flip()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
    pygame.quit()
