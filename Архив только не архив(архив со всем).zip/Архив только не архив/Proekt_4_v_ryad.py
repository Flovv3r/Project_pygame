import sys

from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QCheckBox, QTextBrowser
from PyQt5.QtWidgets import QLabel, QLineEdit, QLCDNumber, QRadioButton
from PyQt5.QtGui import QPainter, QColor


class Example_1(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setGeometry(400, 100, 600, 600)
        self.setWindowTitle('4 в ряд')

        self.hod = '0'

        self.do_paint = True
        
        self.lst = [['0' for i in range(6)]for j in range(7)]

        self.label = QLabel('', self)
        self.label.resize(200, 20)
        self.label.move(30, 0)

        self.prav = QPushButton('Правила', self)
        self.prav.resize(100, 20)
        self.prav.move(450, 570)
        self.prav.clicked.connect(self.run_pravila)
        
        self.btn_restart = QPushButton('Новая игра', self)
        self.btn_restart.resize(100, 20)
        self.btn_restart.move(400, 20)
        self.btn_restart.clicked.connect(self.clear)

        self.label_hod = QLabel('Сейчас ходит:', self)
        self.label_hod.resize(150, 20)
        self.label_hod.move(30, 570)

        self.rad1 = QRadioButton('Красные', self)
        self.rad1.move(200, 20)
        self.rad1.toggled.connect(self.red)

        self.rad2 = QRadioButton('Желтые', self)
        self.rad2.move(290, 20)
        self.rad2.toggled.connect(self.yellow)

        self.btn1 = QPushButton('1', self)
        self.btn1.resize(50, 20)
        self.btn1.move(30, 60)
        self.btn1.clicked.connect(self.run1)

        self.btn2 = QPushButton('2', self)
        self.btn2.resize(50, 20)
        self.btn2.move(110, 60)
        self.btn2.clicked.connect(self.run2)

        self.btn3 = QPushButton('3', self)
        self.btn3.resize(50, 20)
        self.btn3.move(190, 60)
        self.btn3.clicked.connect(self.run3)

        self.btn4 = QPushButton('4', self)
        self.btn4.resize(50, 20)
        self.btn4.move(270, 60)
        self.btn4.clicked.connect(self.run4)

        self.btn5 = QPushButton('5', self)
        self.btn5.resize(50, 20)
        self.btn5.move(350, 60)
        self.btn5.clicked.connect(self.run5)

        self.btn6 = QPushButton('6', self)
        self.btn6.resize(50, 20)
        self.btn6.move(430, 60)
        self.btn6.clicked.connect(self.run6)

        self.btn7 = QPushButton('7', self)
        self.btn7.resize(50, 20)
        self.btn7.move(510, 60)
        self.btn7.clicked.connect(self.run7)

    def red(self):
        #меняю ход и начинаю игру заново
        self.hod = 'red'
        self.clear()
        self.label_hod.setText('Сейчас ходит: ' + self.hod)

    def yellow(self):
        #меняю ход и начинаю игру заново
        self.hod = 'yellow'
        self.clear()
        self.label_hod.setText('Сейчас ходит: ' + self.hod)

    def run1(self):
        #рассматриваю ход, если он возможен
        if self.hod != '0':
            if '0' in self.lst[0]:
                self.i = -1
                while self.lst[0][self.i] != '0':
                    self.i -= 1
                self.lst[0][self.i] = self.hod
                #проверяю ход, выиграл он или нет
                self.check(0, self.i)
                if self.hod == 'red':
                    self.hod = 'yellow'
                else:
                    self.hod = 'red'
            else:
                #если ход невозможен
                self.label.setText('Лимит!!! В первом столбце!')
            #ход возможен
            self.label_hod.setText('Сейчас ходит: ' + self.hod)
            self.repaint()
            

    def run2(self):
        if self.hod != '0':
            if '0' in self.lst[1]:
                self.i = -1
                while self.lst[1][self.i] != '0':
                    self.i -= 1
                self.lst[1][self.i] = self.hod
                self.check(1, self.i)
                if self.hod == 'red':
                    self.hod = 'yellow'
                else:
                    self.hod = 'red'
            else:
                self.label.setText('Лимит!!! Во втором столбце!')
            self.label_hod.setText('Сейчас ходит: ' + self.hod)
            self.repaint()

    def run3(self):
        if self.hod != '0':
            if '0' in self.lst[2]:
                self.i = -1
                while self.lst[2][self.i] != '0':
                    self.i -= 1
                self.lst[2][self.i] = self.hod
                self.check(2, self.i)
                if self.hod == 'red':
                    self.hod = 'yellow'
                else:
                    self.hod = 'red'
            else:
                self.label.setText('Лимит!!! В третьем столбце!')
            self.label_hod.setText('Сейчас ходит: ' + self.hod)
            self.repaint()

    def run4(self):
        if self.hod != '0':
            if '0' in self.lst[3]:
                self.i = -1
                while self.lst[3][self.i] != '0':
                    self.i -= 1
                self.lst[3][self.i] = self.hod
                self.check(3, self.i)
                if self.hod == 'red':
                    self.hod = 'yellow'
                else:
                    self.hod = 'red'
            else:
                self.label.setText('Лимит!!! В четвертом столбце!')
            self.label_hod.setText('Сейчас ходит: ' + self.hod)
            self.repaint()

    def run5(self):
        if self.hod != '0':
            if '0' in self.lst[4]:
                self.i = -1
                while self.lst[4][self.i] != '0':
                    self.i -= 1
                self.lst[4][self.i] = self.hod
                self.check(4, self.i)
                if self.hod == 'red':
                    self.hod = 'yellow'
                else:
                    self.hod = 'red'
            else:
                self.label.setText('Лимит!!! В пятом столбце!')
            self.label_hod.setText('Сейчас ходит: ' + self.hod)
            self.repaint()

    def run6(self):
        if self.hod != '0':
            if '0' in self.lst[5]:
                self.i = -1
                while self.lst[5][self.i] != '0':
                    self.i -= 1
                self.lst[5][self.i] = self.hod
                self.check(5, self.i)
                if self.hod == 'red':
                    self.hod = 'yellow'
                else:
                    self.hod = 'red'
            else:
                self.label.setText('Лимит!!! В шестом столбце!')
            self.label_hod.setText('Сейчас ходит: ' + self.hod)
            self.repaint()

    def run7(self):
        if self.hod != '0':
            if '0' in self.lst[6]:
                self.i = -1
                while self.lst[6][self.i] != '0':
                    self.i -= 1
                self.lst[6][self.i] = self.hod
                self.check(6, self.i)
                if self.hod == 'red':
                    self.hod = 'yellow'
                else:
                    self.hod = 'red'
            else:
                self.label.setText('Лимит!!! В седьмом столбце!')
            self.label_hod.setText('Сейчас ходит: ' + self.hod)
            self.repaint()

    def check(self, n, i):
        #рассмастриваю выигрыш хода
        for j in range(4):
            #по горизонтали
            if i - j >= -6 and i + j <= -1:
                if self.lst[n][i - j] == self.lst[n][i - j + 1] == self.lst[n][i - j + 2] == self.lst[n][i - j + 3] == self.hod:
                    self.label.setText('Выиграл, ' + self.hod + '!')
                    break
                
            #по диагонали снизу слева вверх справа
            if n - j >= 0 and n + 3 - j <= 6 and -1 >= i + j - 3 >= -6 and -6 <= i + j <= -1:
                if self.lst[n - j][i + j] == self.lst[n + 1 - j][i - 1 + j] == self.lst[n + 2 - j][i - 2 + j] == self.lst[n + 3 - j][i - 3 + j] == self.hod:
                    self.label.setText('Выиграл, ' + self.hod + '!')
                    break
            #по диагонали сверху слева вниз справа
            if n + j <= 6 and n - 3 + j >= 0 and -1 >= i + j - 3 >= -6 and -6 <= i + j <= -1:
                if self.lst[n + j][i + j] == self.lst[n - 1 + j][i - 1 + j] == self.lst[n - 2 + j][i - 2 + j] == self.lst[n - 3 + j][i - 3 + j] == self.hod:
                    self.label.setText('Выиграл, ' + self.hod + '!')
                    break

            #по вертикали
            if n - j >= 0 and n - j + 3 <= 6:
                if self.lst[n - j][i] == self.lst[n - j + 1][i] == self.lst[n - j + 2][i] == self.lst[n - j + 3][i] == self.hod:
                    self.label.setText('Выиграл, ' + self.hod + '!')
                    break

    def clear(self):
        #очищаю весь список (начинаю заново игру)
        self.lst = [['0' for i in range(6)]for j in range(7)]
        self.label.setText('')
        self.repaint()

    def paintEvent(self, event):
        if self.do_paint:
            #рисую поле для игры
            qp = QPainter()
            qp.begin(self)
            qp.setBrush(QColor(0, 0, 0))
            qp.drawRect(30, 100, 530, 445)
            qp.setBrush(QColor(0, 72, 186))
            qp.drawRect(30, 170, 530, 5)
            qp.drawRect(30, 245, 530, 5)
            qp.drawRect(30, 320, 530, 5)
            qp.drawRect(30, 395, 530, 5)
            qp.drawRect(30, 470, 530, 5)
            qp.drawRect(100, 100, 7, 445)
            qp.drawRect(177, 100, 7, 445)
            qp.drawRect(254, 100, 7, 445)
            qp.drawRect(331, 100, 7, 445)
            qp.drawRect(408, 100, 7, 445)
            qp.drawRect(484, 100, 7, 445)
            qp.setBrush(QColor(57,194,135))
            qp.drawRect(25, 95, 540, 5)
            qp.drawRect(25, 545, 540, 5)
            qp.drawRect(25, 95, 5, 455)
            qp.drawRect(560, 95, 5, 455)
            #пробегаюсь по всему списку и рисую круг, в зависимости от значения перменной 
            for k in range(len(self.lst)):
                for h in range(len(self.lst[k])):
                    if self.lst[k][h] == 'red':
                        qp.setBrush(QColor(246, 62, 32))
                        qp.drawEllipse(30 + k * (77), 100 + h * (75), 70, 70)
                    elif self.lst[k][h] == 'yellow':
                        qp.setBrush(QColor(242, 241, 4))
                        qp.drawEllipse(30 + k * (77), 100 + h * (75), 70, 70)
            qp.end()

    def run_pravila(self):
        #открытие доп окна с правилами
        self.pravila = Pravila()
        self.pravila.show()


class Pravila(QWidget):
    #создание класса для отдельного окна, в котором записаны правила игры
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setGeometry(300, 100, 410, 160)
        self.setWindowTitle('Правила 4 в ряд')

        #создание поля для правил и его заполнение
        self.qtb = QTextBrowser(self)
        self.qtb.resize(400, 130)
        self.qtb.move(5, 5)
        #открываю файл с правилами игры и передаю содержимое в диалоговое окно программы
        f = open('Pravila.txt', 'r').read()
        self.qtb.setPlainText(f)
        self.qtb.setPlainText(self.qtb.toPlainText() + '\nПравила игры.\n Задано поле 6х7, поочередно ходят два пользователя - желтый и красный. Они кладут фишки соответственно желтого и красного цвета. Нельзя класть фишки за пределами игрового поля.')
        self.qtb.setPlainText(self.qtb.toPlainText() + '\nЦель игры.\n Сложить фишки одного цвета по горизонтали, вертикали, или диагоналям.')            
            
def main_1():
    app_1 = QApplication(sys.argv)
    ex_1 = Example_1()
    ex_1.show()
    sys.exit(app_1.exec())
main_1()